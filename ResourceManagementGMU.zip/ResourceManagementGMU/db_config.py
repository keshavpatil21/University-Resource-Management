# db_config.py
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'gm_university_db'
}


