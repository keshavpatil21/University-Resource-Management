from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
from db_config import db_config

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# Home route
def get_connection():
    return mysql.connector.connect(**db_config)

@app.route('/')
def home():
    return render_template('home.html')

# Free Resources
@app.route('/free/resources', methods=['GET', 'POST'])
def view_free_resources():
    resources = []
    selected_weekday = None
    selected_time_slot = None

    if request.method == 'POST':
        selected_weekday = request.form['weekday']
        selected_time_slot = request.form['time_slot']

        conn = get_connection()
        cursor = conn.cursor(dictionary=True)

        query = """
            SELECT r.RESOURCE_ID, r.TYPE, r.CAPACITY, r.location
            FROM resources r
            WHERE r.RESOURCE_ID NOT IN (
                SELECT RESOURCE_ID
                FROM timetable
                WHERE WEEKDAY = %s AND TIME_SLOT = %s AND RESOURCE_ID IS NOT NULL
            );
        """
        cursor.execute(query, (selected_weekday, selected_time_slot))
        resources = cursor.fetchall()

        cursor.close()
        conn.close()

    return render_template(
        'view_free_resources.html',
        resources=resources,
        selected_weekday=selected_weekday,
        selected_time_slot=selected_time_slot
    )

# Free Faculty
@app.route('/free/faculty', methods=['GET', 'POST'])
def view_free_faculty():
    faculty = []
    selected_weekday = None
    selected_time_slot = None

    if request.method == 'POST':
        selected_weekday = request.form['weekday']
        selected_time_slot = request.form['time_slot']

        conn = get_connection()
        cursor = conn.cursor(dictionary=True)

        query = """
            SELECT f.FACULTY_ID, f.NAME, f.DESIGNATION, d.NAME AS DEPARTMENT
            FROM faculty f
            JOIN department d ON f.DEP_ID = d.DEP_ID
            WHERE f.FACULTY_ID NOT IN (
                SELECT FACULTY_ID
                FROM timetable
                WHERE WEEKDAY = %s AND TIME_SLOT = %s AND FACULTY_ID IS NOT NULL
            );
        """
        cursor.execute(query, (selected_weekday, selected_time_slot))
        faculty = cursor.fetchall()

        cursor.close()
        conn.close()

    return render_template(
        'view_free_faculty.html',
        faculty=faculty,
        selected_weekday=selected_weekday,
        selected_time_slot=selected_time_slot
    )

# Report: Resource Schedule
@app.route('/report/resource_schedule')
def report_resource_schedule():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM timetable ORDER BY RESOURCE_ID, WEEKDAY, TIME_SLOT")
    schedule = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('report_resource_schedule.html', schedule=schedule)

# Report: Faculty Schedule
@app.route('/report/faculty_schedule', methods=['GET', 'POST'])
def report_faculty_schedule():
    schedule = []
    faculty_list = []
    selected_faculty = None

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT FACULTY_ID, NAME FROM faculty")
    faculty_list = cursor.fetchall()

    if request.method == 'POST':
        selected_faculty = request.form['faculty_id']
        cursor.execute("SELECT * FROM timetable WHERE FACULTY_ID = %s ORDER BY WEEKDAY, TIME_SLOT", (selected_faculty,))
        schedule = cursor.fetchall()

    cursor.close()
    conn.close()
    return render_template('report_faculty_schedule1.html', schedule=schedule, faculty_list=faculty_list, selected_faculty=selected_faculty)

# Report: Section Schedule
@app.route('/report/section_schedule', methods=['GET', 'POST'])
def report_section_schedule():
    schedule = []
    section = None

    if request.method == 'POST':
        section = request.form['resources']

        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM timetable WHERE SECTION = 'A' ORDER BY WEEKDAY, TIME_SLOT", (resources,))
        schedule = cursor.fetchall()
        cursor.close()
        conn.close()

    return render_template('report_section_schedule1.html', schedule=schedule, section=section)

# Add Resource
@app.route('/add/resource', methods=['GET', 'POST'])
def add_resource():
    if request.method == 'POST':
        resource_id = request.form['resource_id']
        resource_type = request.form['type']
        capacity = request.form['capacity']
        location = request.form['location']

        conn = get_connection()
        cursor = conn.cursor()

        query = """
            INSERT INTO resources (RESOURCE_ID, TYPE, CAPACITY, location)
            VALUES (%s, %s, %s, %s)
        """
        try:
            cursor.execute(query, (resource_id, resource_type, capacity, location))
            conn.commit()
            flash('Resource added successfully.', 'success')
        except mysql.connector.Error as err:
            flash(f'Error: {err}', 'danger')
        finally:
            cursor.close()
            conn.close()

        return redirect(url_for('add_resource'))

    return render_template('add_resource.html')

# Add Faculty
@app.route('/add/faculty', methods=['GET', 'POST'])
def add_faculty():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT DEP_ID, NAME FROM department")
    departments = cursor.fetchall()
    cursor.close()
    conn.close()

    if request.method == 'POST':
        faculty_id = request.form['faculty_id']
        name = request.form['name']
        designation = request.form['designation']
        dep_id = request.form['dep_id']

        conn = get_connection()
        cursor = conn.cursor()

        query = """
            INSERT INTO faculty (FACULTY_ID, NAME, DESIGNATION, DEP_ID)
            VALUES (%s, %s, %s, %s)
        """
        try:
            cursor.execute(query, (faculty_id, name, designation, dep_id))
            conn.commit()
            flash('Faculty added successfully.', 'success')
        except mysql.connector.Error as err:
            flash(f'Error: {err}', 'danger')
        finally:
            cursor.close()
            conn.close()

        return redirect(url_for('add_faculty'))

    return render_template('add_faculty.html', departments=departments)

# Add Department
@app.route('/add/department', methods=['GET', 'POST'])
def add_department():
    if request.method == 'POST':
        dep_id = request.form['dep_id']
        name = request.form['name']

        conn = get_connection()
        cursor = conn.cursor()

        query = """
            INSERT INTO department (DEP_ID, NAME)
            VALUES (%s, %s)
        """
        try:
            cursor.execute(query, (dep_id, name))
            conn.commit()
            flash('Department added successfully.', 'success')
        except mysql.connector.Error as err:
            flash(f'Error: {err}', 'danger')
        finally:
            cursor.close()
            conn.close()

        return redirect(url_for('add_department'))

    return render_template('add_department.html')

if __name__ == '__main__':
    app.run(debug=True)
