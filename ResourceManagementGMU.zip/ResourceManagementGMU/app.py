from flask import Flask, render_template, request, redirect, url_for, flash, session
import mysql.connector
from db_config import db_config
from functools import wraps

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# --------------------------- UTILITY ---------------------------

def get_connection():
    return mysql.connector.connect(**db_config)

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function
def role_required(*roles):
    def wrapper(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'role' not in session or session['role'] not in roles:
                flash("You do not have permission to access this page.", "danger")
                return redirect(url_for('home'))
            return f(*args, **kwargs)
        return decorated_function
    return wrapper
 

# --------------------------- ROUTES ---------------------------

from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import check_password_hash
# ... other imports

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()

        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['user_id']
            session['username'] = user['username']
            session['role'] = user['role']
            
            return redirect(url_for('home'))  # redirect to home
        else:
            flash("Invalid credentials", "danger")

        cursor.close()
        conn.close()

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for('login'))


@app.route('/home')
@login_required
def home():
    return render_template('home.html')


# --------------------------- RESOURCE VIEW ---------------------------

@app.route('/free/resources', methods=['GET', 'POST'])
@login_required
def view_free_resources():
    resources = []
    selected_weekday = None
    selected_time_slot = None

    if request.method == 'POST':
        selected_weekday = request.form['weekday']
        selected_time_slot = request.form['time_slot']

        conn = get_connection()
        cursor = conn.cursor(dictionary=True)

        query = """
            SELECT r.RESOURCE_ID, r.TYPE, r.CAPACITY, r.location
            FROM resources r
            WHERE r.RESOURCE_ID NOT IN (
                SELECT RESOURCE_ID FROM timetable
                WHERE WEEKDAY = %s AND TIME_SLOT = %s AND RESOURCE_ID IS NOT NULL
            );
        """
        cursor.execute(query, (selected_weekday, selected_time_slot))
        resources = cursor.fetchall()
        cursor.close()
        conn.close()

    return render_template('view_free_resources.html',
                           resources=resources,
                           selected_weekday=selected_weekday,
                           selected_time_slot=selected_time_slot)

# --------------------------- FACULTY VIEW ---------------------------

@app.route('/free/faculty', methods=['GET', 'POST'])
@login_required
def view_free_faculty():
    faculty = []
    selected_weekday = None
    selected_time_slot = None

    if request.method == 'POST':
        selected_weekday = request.form['weekday']
        selected_time_slot = request.form['time_slot']

        conn = get_connection()
        cursor = conn.cursor(dictionary=True)

        query = """
            SELECT f.FACULTY_ID, f.NAME, f.DESIGNATION, d.DEP_NAME AS DEPARTMENT
            FROM faculty f
            JOIN department d ON f.DEP_ID = d.DEP_ID
            WHERE f.FACULTY_ID NOT IN (
                SELECT FACULTY_ID FROM timetable
                WHERE WEEKDAY = %s AND TIME_SLOT = %s AND FACULTY_ID IS NOT NULL
            );
        """
        cursor.execute(query, (selected_weekday, selected_time_slot))
        faculty = cursor.fetchall()
        cursor.close()
        conn.close()

    return render_template('view_free_faculty.html',
                           faculty=faculty,
                           selected_weekday=selected_weekday,
                           selected_time_slot=selected_time_slot)

# --------------------------- REPORTS ---------------------------

@app.route('/report/resource_schedule')
@login_required
def report_resource_schedule():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM timetable ORDER BY RESOURCE_ID, WEEKDAY, TIME_SLOT")
    schedule = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('report_resource_schedule.html', schedule=schedule)


@app.route('/report/faculty_schedule', methods=['GET', 'POST'])
@login_required
def report_faculty_schedule():
    schedule = []
    faculty_list = []
    selected_faculty = None

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT FACULTY_ID, NAME FROM faculty")
    faculty_list = cursor.fetchall()

    if request.method == 'POST':
        selected_faculty = request.form['faculty_id']
        cursor.execute("SELECT * FROM timetable WHERE FACULTY_ID = %s ORDER BY WEEKDAY, TIME_SLOT", (selected_faculty,))
        schedule = cursor.fetchall()

    cursor.close()
    conn.close()
    return render_template('report_faculty_schedule1.html',
                           schedule=schedule,
                           faculty_list=faculty_list,
                           selected_faculty=selected_faculty)


@app.route('/report/section_schedule', methods=['GET', 'POST'])
@login_required
def report_section_schedule():
    schedule = []
    academic_years = []
    semesters = []
    sections = []

    selected_year = None
    selected_semester = None
    selected_section = None

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT DISTINCT ACADEMIC_YEAR FROM timetable ORDER BY ACADEMIC_YEAR DESC")
    academic_years = cursor.fetchall()

    if request.method == 'POST':
        selected_year = request.form.get('academic_year')
        selected_semester = request.form.get('semester')
        selected_section = request.form.get('section')

        query = """
            SELECT * FROM timetable
            WHERE ACADEMIC_YEAR = %s AND SEMESTER = %s AND SECTION = %s
            ORDER BY WEEKDAY, TIME_SLOT
        """
        cursor.execute(query, (selected_year, selected_semester, selected_section))
        schedule = cursor.fetchall()

    if selected_year:
        cursor.execute("SELECT DISTINCT SEMESTER FROM timetable WHERE ACADEMIC_YEAR = %s", (selected_year,))
        semesters = cursor.fetchall()

    if selected_year and selected_semester:
        cursor.execute("""
            SELECT DISTINCT SECTION FROM timetable
            WHERE ACADEMIC_YEAR = %s AND SEMESTER = %s
        """, (selected_year, selected_semester))
        sections = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template('report_section_schedule2.html',
                           academic_years=academic_years,
                           semesters=semesters,
                           sections=sections,
                           selected_year=selected_year,
                           selected_semester=selected_semester,
                           selected_section=selected_section,
                           schedule=schedule)

# --------------------------- ADD FUNCTIONS ---------------------------

@app.route('/add/resource', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def add_resource():
    if request.method == 'POST':
        resource_id = request.form['resource_id']
        resource_type = request.form['type']
        capacity = request.form['capacity']
        location = request.form['location']

        conn = get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute("""
                INSERT INTO resources (RESOURCE_ID, TYPE, CAPACITY, location)
                VALUES (%s, %s, %s, %s)
            """, (resource_id, resource_type, capacity, location))
            conn.commit()
            flash('Resource added successfully.', 'success')
        except mysql.connector.Error as err:
            flash(f'Error: {err}', 'danger')
        finally:
            cursor.close()
            conn.close()

        return redirect(url_for('add_resource'))

    return render_template('add_resource.html')


@app.route('/add/faculty', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def add_faculty():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT DEP_ID, DEP_NAME FROM department")
    departments = cursor.fetchall()
    cursor.close()
    conn.close()

    if request.method == 'POST':
        faculty_id = request.form['faculty_id']
        name = request.form['name']
        designation = request.form['designation']
        dep_id = request.form['dep_id']

        conn = get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute("""
                INSERT INTO faculty (FACULTY_ID, NAME, DESIGNATION, DEP_ID)
                VALUES (%s, %s, %s, %s)
            """, (faculty_id, name, designation, dep_id))
            conn.commit()
            flash('Faculty added successfully.', 'success')
        except mysql.connector.Error as err:
            flash(f'Error: {err}', 'danger')
        finally:
            cursor.close()
            conn.close()

        return redirect(url_for('add_faculty'))

    return render_template('add_faculty.html', departments=departments)


@app.route('/add/department', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def add_department():
    if request.method == 'POST':
        dep_id = request.form['dep_id']
        name = request.form['name']

        conn = get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute("""
                INSERT INTO department (DEP_ID, NAME)
                VALUES (%s, %s)
            """, (dep_id, name))
            conn.commit()
            flash('Department added successfully.', 'success')
        except mysql.connector.Error as err:
            flash(f'Error: {err}', 'danger')
        finally:
            cursor.close()
            conn.close()

        return redirect(url_for('add_department'))

    return render_template('add_department.html')

# --------------------------- MAIN ---------------------------

if __name__ == '__main__':
    app.run(debug=True)
